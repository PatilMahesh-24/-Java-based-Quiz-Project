package com.quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

public class SortingByID {
	
	public void getRecordByID() throws SQLException {
		/* Group N: JAVA Quiz Mini-Project
		 * Girish Shinde
		 * Shubham Mundhe
		 * Pradeep Mundhe
		 * Shubham Mane
		 * */
		
		//getting connection from GetConnection class
		//creating Object of GetConnection class
		GetConnection getConnection = new GetConnection();
		Connection connection = null;
		try {
			connection = getConnection.getConnection();
			
			//preparing and executing statement
			PreparedStatement ps1 = connection.prepareStatement("select * from student");
			ResultSet rs = ps1.executeQuery();

			//creating ArrayList for sorting records by ID
			ArrayList<Integer> al = new ArrayList<Integer>();
			// getting all id's from the database storing in ArrayList			
			while (rs.next()) {
				al.add(rs.getInt(1));
			}
			
			System.out.println("Size of database: " + al.size());
			System.out.println("before sorting: " + al);
			
			//data was already in sorted manner because of primary key auto increment
			Collections.shuffle(al);
			System.out.println("After shuffling: "+ al);

			//using Collections class's sort method to sort all the IDs
			Collections.sort(al);
			System.out.println("after sorting: " + al);
			
			// System.out.println("------------------------------------------------------------------------------------------------------------------------");
			
			System.out.println();
			System.out.println("Records in Sorted order by ID :");
			
			//loop for printing all the records in sorted order
			System.out.println("------------------------------------------------------------------------------------------------------------------------");
			System.out.println("Id: \t|Name \t|LastName \t|Mobile_Number \t|Marks \t|Rank");
			System.out.println("------------------------------------------------------------------------------------------------------------------------");
			
			for (int i = 0; i < (al.size()+2); i++) {
				
				//preparing and executing prepareStatement
				PreparedStatement ps2 = connection.prepareStatement
						("select * from student where id = " + i);
				ResultSet rs2 = ps2.executeQuery();
				
				//printing i'th record
				/*while (rs2.next()) {
					System.out.print("Id. " + rs2.getInt(1));
					System.out.print(" Name: " + rs2.getString(2));
					System.out.print(" LastName: " + rs2.getString(3));
					System.out.print(" Mobile Number: " + rs2.getString(4));
					System.out.print(" Marks: " + rs2.getString(5));
					System.out.print(" Rank/Class: " + rs2.getString(6));
					System.out.println();
				}*/
				
				//in a tabular format:
				while (rs2.next()) {
					System.out.println(rs2.getInt(1)+" \t|"+rs2.getString(2)+" \t|"+rs2.getString(3)+
							" \t|"+rs2.getString(4)+" \t|"+rs2.getString(5)+" \t|"+rs2.getString(6));
					System.out.println("------------------------------------------------------------------------------------------------------------------------");
					}
				}	
			
			// System.out.println("------------------------------------------------------------------------------------------------------------------------");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}
}
