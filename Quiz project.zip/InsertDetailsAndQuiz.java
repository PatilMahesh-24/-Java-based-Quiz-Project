package com.quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class InsertDetailsAndQuiz {
	/* Group N: JAVA Quiz Mini-Project
	 * Girish Shinde
	 * Shubham Mundhe
	 * Pradeep Mundhe
	 * Shubham Mane
	 * */

	//initializing marks to 0
	int marks = 0;
	
	
	//method 
	public int insertStudentData(String firstName, String lastName, String mobile) throws SQLException {
		
		GetConnection getConnection = new GetConnection();
		Scanner sc = new Scanner(System.in);
		PreparedStatement ps = null;
		Connection connection = null;
		
		try {
			//establishing connection
			connection = getConnection.getConnection();
			
			//declaring ArrayList for generating 10 random numbers.
			ArrayList<Integer> list = new ArrayList<Integer>();
			for (int i = 1; i <= 10; i++) {
				list.add(i);
			}
			Collections.shuffle(list); 
			//shuffle method for random numbers in Collections class
			
			for (int i = 0; i < 10; i++) {
				//preparing MySQL statement 
				PreparedStatement ps1 = connection.prepareStatement("select * from quiz where id = " + list.get(i));
				//executing MySQL statement query
				ResultSet rs = ps1.executeQuery();
				//retrieving data from ResultSet Object by using next() method
				while (rs.next()) {
					System.out.println("Q. Id. " + rs.getInt(1));
					System.out.println("Question: =" + rs.getString(2));
					System.out.println(rs.getString(3));
					System.out.println(rs.getString(4));
					System.out.println(rs.getString(5));
					System.out.println(rs.getString(6));
					int ans = rs.getInt(7);

					//getting answer from the student
					System.out.println("Enter your Response.");
					
					int studentAns = sc.nextInt();

					//checking if ans is correct and if correct then incrementing marks variable
					if (studentAns == ans) {
						marks = marks + 1;
					}
				}
			}
			
			//preparing statement for insertion into student table
			ps = connection
					.prepareStatement("insert into student(firstName,lastName,mobile,marks,studentRank)values(?,?,?,?,?)");
			ps.setString(1, firstName);
			ps.setString(2, lastName);
			ps.setString(3, mobile);
			ps.setInt(4, marks);
			ps.setString(5, getRank(marks));
			
			//executing the prepared statement
			int i = ps.executeUpdate();
			
			System.out.println("------------------------------------------------------------------------------------------------------------------------");
			System.out.println("Congratulations! " + i + " Record inserted successfully.");
			System.out.println("------------------------------------------------------------------------------------------------------------------------");
			
			//code to get student ID and display it to the student for future purposes
			//preparing statement
			PreparedStatement ps3 = connection.prepareStatement
					("select * from student WHERE firstName = " + "'" +firstName+ "'"
			+ " AND lastName = " + "'" +lastName+ "'"
			+ " AND mobile = " + "'" +mobile+ "'"  );
			//executing statement
			ResultSet rs3 = ps3.executeQuery();
			//retrieving ID and showing it to the user.
			while (rs3.next()) {
				System.out.println("Remember your Id for Marks retrieval in future. = " + rs3.getInt(1));
				}
			System.out.println("------------------------------------------------------------------------------------------------------------------------");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
			ps.close();
			sc.close();
		}
		//returning marks to show the user
		return marks;		
	}

	//method to calculate rank or class of student 
	public String getRank(int myMarks) {
		if (myMarks >= 8 && myMarks <= 10) {
			return "Class A";
		} else if (myMarks >= 6 && myMarks < 8) {
			return "Class B";
		} else if (myMarks == 5) {
			return "Class C";
		}
		return "Class D or Fail";
	}
}
