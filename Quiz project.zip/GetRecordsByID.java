package com.quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetRecordsByID {
	/* Group N: JAVA Quiz Mini-Project
	 * Girish Shinde
	 * Shubham Mundhe
	 * Pradeep Mundhe
	 * Shubham Mane
	 * */
	
	Connection connectionStudent = null;
	
	//method to get record by ID
	public void getRecordByID(int id) throws SQLException {
		//creating Object of GetConnection class
		GetConnection getConnection = new GetConnection();
		try {
			connectionStudent = getConnection.getConnection();

			//preparing and executing preparedStatement
			PreparedStatement ps1 = connectionStudent.prepareStatement("select * from student where id = " + id);
			ResultSet rs = ps1.executeQuery();

			//printing record
			while (rs.next()) {
				System.out.println("Id. " + rs.getInt(1));
				System.out.println("Name: " + rs.getString(2));
				System.out.println("LastName: " + rs.getString(3));
				System.out.println("Mobile Number: " + rs.getString(4));
				System.out.println("Marks: " + rs.getString(5));
				System.out.println("Rank/Class: " + rs.getString(6));
			}
			
			ps1.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connectionStudent.close();
			
		}
	}
}
