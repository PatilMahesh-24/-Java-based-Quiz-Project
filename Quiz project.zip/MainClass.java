package com.quiz;

import java.sql.SQLException;
import java.util.Scanner;

public class MainClass {
	/* Group N: JAVA Quiz Mini-Project
	 * Girish Shinde
	 * Shubham Mundhe
	 * Pradeep Mundhe
	 * Shubham Mane
	 * */

	public static void main(String[] args) throws SQLException  {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome JAVA Quiz! Please choose: ");
		System.out.println("* To appear for Test, press 1.");
		System.out.println("* To know your Marks, press 2.");
		System.out.println("* To get all Records, press 3.");
		int choice = sc.nextInt();

		if (choice == 1) {
			//getting input from user
			System.out.println("Please Enter your First Name: ");
			String firstName = sc.next();
			System.out.println("Please Enter your Last Name: ");
			String lastName = sc.next();
			System.out.println("Enter Mobile Number: ");
			String mobile = sc.next();
			
			System.out.println("Congratulations! You've been Successfully Registered.");
			System.out.println("Are you ready for the test? (y/n)");
			char ch = sc.next().charAt(0);
			
			if (ch == 'y') {
				
				//calling method insertStudentData from InsertDetailsAndQuiz class
				InsertDetailsAndQuiz insertDetailsAndQuiz = new InsertDetailsAndQuiz();
				int yourMarks = insertDetailsAndQuiz.insertStudentData(firstName, lastName, mobile);
				System.out.println("Marks Obtained: " + yourMarks);
				System.out.println("*****************");
				
			} else {
				System.out.println("Ok. Exiting program. Thank You!");
			}

		} else if (choice == 2) {
			
			// calling method for retrieving record from database
			System.out.println("Enter ID to get Record: ");
			int id = sc.nextInt();
			GetRecordsByID getRecordsByID = new GetRecordsByID();
			getRecordsByID.getRecordByID(id);
			
		} else if (choice == 3){
			
			//calling sortingByID method from SortingByID class
			SortingByID sortingByID = new SortingByID();
			sortingByID.getRecordByID();
			
		}else {
			System.out.println("Invalid Choice.");
		}
		sc.close();
	}
}
