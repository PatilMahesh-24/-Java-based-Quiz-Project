package com.quiz;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection {
	/* Group N: JAVA Quiz Mini-Project
	 * Girish Shinde
	 * Shubham Mundhe
	 * Pradeep Mundhe
	 * Shubham Mane
	 * */
	
	Connection connection = null;
	
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/miniproject_quiz?useSSL=false", "root", "Shinde@21");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
}
